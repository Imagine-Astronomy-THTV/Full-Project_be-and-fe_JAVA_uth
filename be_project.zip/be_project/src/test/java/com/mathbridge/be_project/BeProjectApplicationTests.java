package com.mathbridge.be_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
